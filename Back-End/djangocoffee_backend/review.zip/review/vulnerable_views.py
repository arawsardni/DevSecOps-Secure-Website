from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

from .models import Review, Product
from django.contrib.auth import get_user_model

User = get_user_model()

@csrf_exempt
def vulnerable_create_review(request):
    """
    A deliberately vulnerable view that creates a review without CSRF protection.
    This endpoint is for demonstration purposes only to show CSRF vulnerabilities.
    
    DO NOT USE IN PRODUCTION.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)
    
    try:
        data = json.loads(request.body)
        
        # Get the authenticated user
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required'}, status=401)
        
        # Get product
        try:
            product_id = data.get('product_id')
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return JsonResponse({'error': 'Product not found'}, status=404)
        
        # Create review
        rating = data.get('rating')
        comment = data.get('comment')
        
        if not rating or not comment:
            return JsonResponse({'error': 'Rating and comment are required'}, status=400)
        
        # Check if user already reviewed this product
        if Review.objects.filter(user=request.user, product=product).exists():
            # Update existing review
            review = Review.objects.get(user=request.user, product=product)
            review.rating = rating
            review.comment = comment
            review.save()
        else:
            # Create new review
            review = Review.objects.create(
                user=request.user,
                product=product,
                rating=rating,
                comment=comment
            )
        
        return JsonResponse({
            'status': 'success',
            'review_id': str(review.id),
            'message': 'Review created successfully'
        })
    
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@csrf_exempt
def vulnerable_delete_review(request, review_id):
    """
    A deliberately vulnerable view that deletes a review without CSRF protection.
    This endpoint is for demonstration purposes only to show CSRF vulnerabilities.
    
    DO NOT USE IN PRODUCTION.
    """
    if request.method != 'POST' and request.method != 'DELETE':
        return JsonResponse({'error': 'Only POST and DELETE methods are allowed'}, status=405)
    
    try:
        # Get the authenticated user
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required'}, status=401)
        
        # Get review
        try:
            review = Review.objects.get(id=review_id)
        except Review.DoesNotExist:
            return JsonResponse({'error': 'Review not found'}, status=404)
        
        # Check if user owns this review
        if review.user != request.user and not request.user.is_staff:
            return JsonResponse({'error': 'You can only delete your own reviews'}, status=403)
        
        # Delete review
        review.delete()
        
        return JsonResponse({
            'status': 'success',
            'message': 'Review deleted successfully'
        })
    
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)